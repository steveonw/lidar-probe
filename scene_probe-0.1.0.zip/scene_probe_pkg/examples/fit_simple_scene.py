"""
End-to-end demo: build a "truth" scene, displace its primitives to make a
deliberately-wrong hypothesis, then run the Probe to recover the truth from
multi-view observations.

What we expect:
  - Start: hypothesis is visibly wrong (primitives in wrong places/sizes)
  - During: error decreases monotonically as the Probe accepts good moves
  - End: hypothesis converges close to truth from every view

Produces:
  - assets/probe_convergence.png      (truth vs. initial vs. fitted views)
  - assets/probe_error_curve.png      (error over iterations)

Run: PYTHONPATH=. python examples/fit_simple_scene.py
"""
import copy
import math
import time

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from scene_lens import (
    Camera, Scene, Primitive,
    fire_burst, render_burst, composite_grid,
)
from scene_probe import (
    Probe, observe_from_scene, build_orbit_cameras,
    render_hypothesis, image_error, build_report,
)


def build_truth_scene():
    """A small scene: ground plane + three primitives we want to recover."""
    R = np.eye(3)
    prims = [
        # Ground plane (big flat box)
        Primitive(
            shape="box", center=np.array([0., -0.4, 0.]),
            half_extents=np.array([8., 0.1, 8.]),
            rotation_matrix=R, inv_rotation_matrix=R,
            color=(0.42, 0.42, 0.45), piece_id=0, piece_type="ground"),
        # Red sphere at (-2, 1, 0) with radius 0.8
        Primitive(
            shape="sphere", center=np.array([-2., 1., 0.]),
            half_extents=np.array([0.8, 0.8, 0.8]),
            rotation_matrix=R, inv_rotation_matrix=R,
            color=(0.85, 0.25, 0.25), piece_id=1, piece_type="ball"),
        # Brown cylinder at (2, 1, 0.5)
        Primitive(
            shape="cylinder", center=np.array([2., 1., 0.5]),
            half_extents=np.array([0.5, 1.0, 0.]),
            rotation_matrix=R, inv_rotation_matrix=R,
            color=(0.65, 0.5, 0.3), piece_id=2, piece_type="pillar"),
        # Blue box at (0, 0.5, -2)
        Primitive(
            shape="box", center=np.array([0., 0.5, -2.]),
            half_extents=np.array([1.0, 0.5, 0.5]),
            rotation_matrix=R, inv_rotation_matrix=R,
            color=(0.3, 0.45, 0.7), piece_id=3, piece_type="block"),
    ]
    return Scene(primitives=prims)


def displace_scene(truth: Scene, rng_seed: int = 0,
                   pos_jitter: float = 1.2, size_jitter: float = 0.4) -> Scene:
    """Make a deliberately-wrong hypothesis by perturbing every primitive's
    position and size. The ground plane is kept (we're recovering objects,
    not floors).
    """
    rng = np.random.default_rng(rng_seed)
    new_prims = []
    for i, p in enumerate(truth.primitives):
        np_p = copy.deepcopy(p)
        if i == 0:
            new_prims.append(np_p)  # keep ground
            continue
        np_p.center = np_p.center + rng.normal(0, pos_jitter, size=3)
        np_p.half_extents = np.maximum(
            np_p.half_extents * np.exp(rng.normal(0, size_jitter, size=3)),
            0.1,
        )
        new_prims.append(np_p)
    return Scene(primitives=new_prims)


def render_view_strip(scene: Scene, cams, label: str, dot_size=2, n_samples=8000):
    """Render `scene` from each camera; return composite strip with label."""
    images = []
    titles = []
    for i, cam in enumerate(cams):
        burst = fire_burst(cam, scene, n_samples=n_samples, seed=200 + i)
        img = render_burst(burst, mode="shaded", dot_size=dot_size,
                           auto_calibrate=True)
        images.append(img)
        titles.append(f"{label} · cam{i}")
    return composite_grid(images, titles, cols=len(cams), pad=6, label_h=20)


def main():
    # ── Build truth + hypothesis ──
    truth = build_truth_scene()
    hypothesis = displace_scene(truth, rng_seed=0)
    print(f"truth: {len(truth.primitives)} primitives")
    print(f"hypothesis: {len(hypothesis.primitives)} primitives (displaced)")

    # ── Build observation cameras (the "views" the probe can query) ──
    # 8 orbiting cameras at moderate angles. These produce the evidence.
    obs_cams = build_orbit_cameras(n=8, radius=7.0, height=2.5,
                                   target=(0, 0.8, 0),
                                   fov_deg=50,
                                   width=180, height_px=140)
    observations = [observe_from_scene(truth, c, n_samples=4000, seed=10 + i)
                    for i, c in enumerate(obs_cams)]
    print(f"captured {len(observations)} observations of truth scene")

    # Cameras for the convergence figure (separate from observation cams —
    # we want clean hero views, not the small ones the probe uses internally)
    hero_cams = [
        Camera(position=np.array([6, 3, 6]), target=np.array([0, 0.8, 0]),
               fov_deg=45, lens="pinhole", width=300, height=220),
        Camera(position=np.array([0, 10, 0.01]), target=np.array([0, 0, 0]),
               up=np.array([0, 0, -1]),
               fov_deg=45, lens="pinhole", width=300, height=220),
        Camera(position=np.array([-6, 2, 0]), target=np.array([0, 1, 0]),
               fov_deg=50, lens="pinhole", width=300, height=220),
    ]

    # Snapshot the initial state
    strip_truth = render_view_strip(truth, hero_cams, "TRUTH")
    strip_init = render_view_strip(hypothesis, hero_cams, "BEFORE")

    # ── Run the closed loop ──
    print("\nrunning probe ...")
    t0 = time.perf_counter()
    probe = Probe(
        hypothesis=hypothesis,
        observations=observations,
        perturb_pos_sigma=0.4,
        perturb_size_sigma=0.15,
        replan_every=4,
        seed=11,
    )
    fitted, history = probe.run(max_iters=120, tolerance=0.5, verbose=True)
    elapsed = time.perf_counter() - t0
    print(f"\nprobe ran for {elapsed:.1f}s, {len(history)} iterations")

    # ── Report ──
    report = build_report(probe)
    print("\n── PROBE REPORT ──")
    print(f"  initial error:       {report.initial_error}")
    print(f"  final error:         {report.final_error}")
    print(f"  error reduction:     {report.error_reduction_pct}%")
    print(f"  iterations:          {report.iterations}")
    print(f"  accept rate:         {report.accept_rate * 100:.1f}%")
    print(f"  final primitives:")
    for p, t in zip(report.final_primitives, truth.primitives):
        print(f"    {p['shape']:8s} fitted center {p['center']}")
        print(f"             truth  center [{t.center[0]:.3f}, {t.center[1]:.3f}, {t.center[2]:.3f}]")

    # Snapshot the final state
    strip_after = render_view_strip(fitted, hero_cams, "AFTER")

    # ── Convergence figure: stack TRUTH / BEFORE / AFTER strips vertically ──
    pad = 12
    w = max(strip_truth.width, strip_init.width, strip_after.width)
    h = strip_truth.height + strip_init.height + strip_after.height + 3 * pad
    cmp = Image.new("RGB", (w, h), "#0a0a0e")
    y = pad // 2
    for strip in (strip_truth, strip_init, strip_after):
        cmp.paste(strip, ((w - strip.width) // 2, y))
        y += strip.height + pad
    cmp.save("assets/probe_convergence.png")
    print("\nwrote assets/probe_convergence.png")

    # ── Error curve: plot err_after over iterations ──
    plot_w, plot_h = 800, 300
    plot = Image.new("RGB", (plot_w, plot_h), "#0a0a0e")
    draw = ImageDraw.Draw(plot)
    errs = [h.err_after for h in history]
    if errs:
        max_err = max(errs)
        min_err = min(errs)
        spread = max(1e-6, max_err - min_err)
        margin = 40
        # axes
        draw.line([(margin, plot_h - margin), (plot_w - 20, plot_h - margin)],
                  fill="#888", width=1)
        draw.line([(margin, 20), (margin, plot_h - margin)],
                  fill="#888", width=1)
        # data
        n = len(errs)
        for i, e in enumerate(errs):
            x = margin + (plot_w - margin - 20) * (i / max(1, n - 1))
            y = (plot_h - margin) - (plot_h - margin - 20) * ((e - min_err) / spread)
            color = "#4ec9b0" if history[i].accepted else "#666"
            draw.ellipse([x - 2, y - 2, x + 2, y + 2], fill=color)
        # labels
        try:
            font = ImageFont.load_default()
        except Exception:
            font = None
        draw.text((margin, 4), f"per-iter error · {n} iterations  "
                                f"start {max_err:.1f} → end {errs[-1]:.1f}",
                  fill="#ddd", font=font)
        draw.text((plot_w - 200, plot_h - 18),
                  "green = accepted · grey = rejected", fill="#aaa", font=font)
    plot.save("assets/probe_error_curve.png")
    print("wrote assets/probe_error_curve.png")


if __name__ == "__main__":
    main()
