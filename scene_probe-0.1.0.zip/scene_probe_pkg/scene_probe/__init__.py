"""
scene_probe — closed-loop active perception built on scene_lens.

Quick start:

    from scene_lens import Scene, Primitive
    from scene_probe import (
        Probe, Observation,
        observe_from_scene, build_orbit_cameras,
        build_report,
    )

    truth = Scene(primitives=[...])  # the real scene (or load from photos)
    cameras = build_orbit_cameras(n=8)
    observations = [observe_from_scene(truth, c) for c in cameras]

    hypothesis = Scene(primitives=[...])  # initial guess
    probe = Probe(hypothesis=hypothesis, observations=observations)
    fitted, history = probe.run(max_iters=100)

    report = build_report(probe)
    print(report)
"""

from .probe import (
    # Data types
    Observation,
    ProbeStep,
    ProbeReport,
    Probe,
    # Helpers
    observe_from_scene,
    render_hypothesis,
    image_error,
    perturb_scene,
    pick_max_error_view,
    build_orbit_cameras,
    build_report,
)

__version__ = "0.1.0"

__all__ = [
    "Probe",
    "Observation",
    "ProbeStep",
    "ProbeReport",
    "observe_from_scene",
    "render_hypothesis",
    "image_error",
    "perturb_scene",
    "pick_max_error_view",
    "build_orbit_cameras",
    "build_report",
]
