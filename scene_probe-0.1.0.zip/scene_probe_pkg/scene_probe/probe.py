"""
scene_probe.probe — closed-loop active perception built on scene_lens.

The Probe maintains a hypothesis Scene (the agent's current guess about
what's out there) and refines it against observed evidence using a simple
guess → render → score → perturb → accept/reject loop. Pure numpy + PIL.

Architecture:

    hypothesis ──→ render ──→ predicted image
                                    │
                                    ↓ compare
    observed image  ─────────────── L
                                    │
                                    ↓ error
                              accept/reject perturbation
                                    │
                                    ↓
                              next viewpoint chosen by max residual
                                    │
                                    ↓
                              re-observe (new burst), repeat

This is hill-climbing, not gradient descent — gradient-free works because
scene_lens isn't differentiable (hard primitive choices break autograd).
Slower than NeRF but produces editable symbolic output: scenes you can
inspect and modify, not opaque neural fields.

LIMITATIONS (honest, not exhaustive):
  - Local minima: hill-climbing without restarts can get stuck.
  - Slow: every step requires N renders. View planning is the dominant cost.
  - Assumes correct primitive count and type — only fits positions/sizes/colors.
  - "Observed" can be a rendered scene (synthetic) or a real image lifted
    into the same lens space (the user provides this).
"""
import copy
import math
from dataclasses import dataclass, field
from typing import List, Callable, Optional, Tuple

import numpy as np
from PIL import Image

from scene_lens import (
    Camera, Scene, Primitive,
    fire_burst, render_burst,
)


# ──────────────────────────────────────────────────────────
# OBSERVATIONS (the "truth" side of the loop)
# ──────────────────────────────────────────────────────────
@dataclass
class Observation:
    """One piece of evidence: a rendered image from a known camera.

    In synthetic experiments, observations come from rendering a ground-truth
    scene. In real-world use, observations would be real photographs lifted
    into one of the scene_lens lens types (typically pinhole) with known
    camera intrinsics.
    """
    cam: Camera
    image: np.ndarray  # (H, W, 3) uint8


def observe_from_scene(scene: Scene, cam: Camera,
                       n_samples: int = 5000, seed: int = 1) -> Observation:
    """Convenience: produce an Observation by rendering a known scene.
    Used for synthetic experiments. For real photos, build an Observation
    directly from the image and known camera."""
    burst = fire_burst(cam, scene, n_samples=n_samples, seed=seed)
    img = render_burst(burst, mode="lidar", auto_calibrate=True, dot_size=2)
    return Observation(cam=cam, image=np.array(img, dtype=np.uint8))


# ──────────────────────────────────────────────────────────
# ERROR (how wrong is the hypothesis at a given camera?)
# ──────────────────────────────────────────────────────────
def render_hypothesis(hypothesis: Scene, cam: Camera,
                      n_samples: int = 5000, seed: int = 7) -> np.ndarray:
    """Render the current hypothesis from a given camera. Returns (H, W, 3)."""
    burst = fire_burst(cam, hypothesis, n_samples=n_samples, seed=seed)
    img = render_burst(burst, mode="lidar", auto_calibrate=True, dot_size=2)
    return np.array(img, dtype=np.uint8)


def image_error(predicted: np.ndarray, observed: np.ndarray) -> float:
    """Mean per-pixel L1 distance between predicted and observed images.

    Cheap baseline error function. Could be replaced with structural
    similarity, silhouette-IoU, or topology-aware error from the silhouette
    layer in the roadmap. Keeping it simple here.
    """
    if predicted.shape != observed.shape:
        # Resize on mismatch (shouldn't happen if caller uses same cam)
        from PIL import Image
        predicted = np.array(Image.fromarray(predicted).resize(
            (observed.shape[1], observed.shape[0])
        ))
    diff = predicted.astype(np.float32) - observed.astype(np.float32)
    return float(np.abs(diff).mean())


# ──────────────────────────────────────────────────────────
# PERTURBATION (how to propose a change to the hypothesis)
# ──────────────────────────────────────────────────────────
def perturb_scene(scene: Scene, rng: np.random.Generator,
                  pos_sigma: float = 0.3,
                  size_sigma: float = 0.1) -> Scene:
    """Propose a random perturbation: pick one primitive, jitter its position
    and/or size. Returns a new Scene (does not modify the input).

    The perturbation distribution is uniform over what to change (position,
    size, or both) but Gaussian in magnitude. Simple, gradient-free, and
    cheap to evaluate.
    """
    if not scene.primitives:
        return scene  # nothing to perturb
    new_scene = Scene(
        primitives=[copy.deepcopy(p) for p in scene.primitives],
        meshes=list(scene.meshes),  # meshes shared, not perturbed for now
    )
    idx = rng.integers(len(new_scene.primitives))
    p = new_scene.primitives[idx]

    mode = rng.choice(["pos", "size", "both"])
    if mode in ("pos", "both"):
        p.center = p.center + rng.normal(0, pos_sigma, size=3)
    if mode in ("size", "both"):
        # Scale half_extents by a small log-normal factor; keep positive
        scale = np.exp(rng.normal(0, size_sigma, size=3))
        p.half_extents = np.maximum(p.half_extents * scale, 0.05)
    return new_scene


# ──────────────────────────────────────────────────────────
# VIEW PLANNING (which camera to fire at next?)
# ──────────────────────────────────────────────────────────
def build_orbit_cameras(n: int = 12, radius: float = 8.0, height: float = 2.5,
                        target: Tuple[float, float, float] = (0, 1, 0),
                        fov_deg: float = 45.0,
                        width: int = 200, height_px: int = 150) -> List[Camera]:
    """Build N pinhole cameras orbiting around a target. Default candidate set
    for the planner. Users can supply their own list."""
    cams = []
    for i in range(n):
        ang = i * 2 * math.pi / n
        pos = np.array([radius * math.cos(ang), height, radius * math.sin(ang)])
        cams.append(Camera(
            position=pos,
            target=np.array(target, dtype=float),
            fov_deg=fov_deg, lens="pinhole",
            width=width, height=height_px,
        ))
    return cams


def pick_max_error_view(hypothesis: Scene,
                        observations: List[Observation]) -> Optional[Observation]:
    """Pick the observation where the current hypothesis is most wrong.
    Naive next-best-view: render hypothesis at each observed cam, compute
    error vs. truth, return the one with highest error.

    For 12 observations × 5000 rays each this is the dominant cost in the
    loop. A real implementation would cache per-view predictions across
    perturbations and only re-render when the hypothesis actually changes.
    """
    if not observations:
        return None
    worst_err, worst_obs = -1.0, None
    for obs in observations:
        pred = render_hypothesis(hypothesis, obs.cam)
        err = image_error(pred, obs.image)
        if err > worst_err:
            worst_err, worst_obs = err, obs
    return worst_obs


# ──────────────────────────────────────────────────────────
# THE PROBE — the loop itself
# ──────────────────────────────────────────────────────────
@dataclass
class ProbeStep:
    """One iteration's record. Useful for plotting convergence and debugging."""
    iter: int
    view_idx: int       # index into the candidate observation list
    err_before: float
    err_after: float
    accepted: bool
    perturb_mode: str   # what changed: pos / size / both


@dataclass
class Probe:
    """Closed-loop active perception over a hypothesis Scene.

    Usage:
        truth = build_some_scene()
        obs = [observe_from_scene(truth, cam) for cam in build_orbit_cameras()]
        hypothesis = build_initial_guess()
        probe = Probe(hypothesis=hypothesis, observations=obs)
        final_scene, history = probe.run(max_iters=100)

    Algorithm: at each step, pick the observation with the highest current
    error (active sampling of disagreement), propose a random perturbation
    to one primitive, accept if error at that view decreases.

    Re-evaluating "highest-error view" is expensive, so by default the planner
    runs every `replan_every` iterations; in between, the loop reuses the
    last-picked view.
    """
    hypothesis: Scene
    observations: List[Observation]
    perturb_pos_sigma: float = 0.3
    perturb_size_sigma: float = 0.1
    replan_every: int = 5
    seed: int = 42
    history: List[ProbeStep] = field(default_factory=list)

    def step(self, rng: np.random.Generator, current_view: Observation,
             view_idx: int) -> ProbeStep:
        """One iteration: propose a perturbation, accept if it helps."""
        # Evaluate current error at this view
        pred_before = render_hypothesis(self.hypothesis, current_view.cam)
        err_before = image_error(pred_before, current_view.image)

        # Propose
        candidate = perturb_scene(self.hypothesis, rng,
                                  pos_sigma=self.perturb_pos_sigma,
                                  size_sigma=self.perturb_size_sigma)
        pred_after = render_hypothesis(candidate, current_view.cam)
        err_after = image_error(pred_after, current_view.image)

        # Accept iff error decreased
        accepted = err_after < err_before
        if accepted:
            self.hypothesis = candidate

        return ProbeStep(
            iter=len(self.history),
            view_idx=view_idx,
            err_before=err_before,
            err_after=err_after if accepted else err_before,
            accepted=accepted,
            perturb_mode="auto",
        )

    def run(self, max_iters: int = 100, tolerance: float = 2.0,
            verbose: bool = False) -> Tuple[Scene, List[ProbeStep]]:
        """Run the closed loop until convergence or budget exhaustion.

        Returns (final_hypothesis, history). The history is a list of
        ProbeSteps suitable for plotting err_after vs. iter.

        Stop conditions:
          - err_after < tolerance (converged)
          - max_iters reached (budget exhausted)
          - no observations (nothing to fit against)
        """
        if not self.observations:
            return self.hypothesis, self.history
        rng = np.random.default_rng(self.seed)

        current_view = self.observations[0]
        current_idx = 0
        for i in range(max_iters):
            if i % self.replan_every == 0:
                # Re-plan: pick the observation where hypothesis is worst.
                # Use identity-based search to avoid numpy-array __eq__ issues.
                picked = pick_max_error_view(self.hypothesis, self.observations)
                if picked is not None:
                    current_view = picked
                    current_idx = next(
                        (j for j, o in enumerate(self.observations) if o is picked),
                        current_idx,
                    )

            rec = self.step(rng, current_view, current_idx)
            self.history.append(rec)
            if verbose and (i % 10 == 0 or rec.accepted):
                print(f"  iter {i:3d} view {rec.view_idx:2d} "
                      f"err {rec.err_before:6.2f} → {rec.err_after:6.2f} "
                      f"{'✓' if rec.accepted else ' '}")
            if rec.err_after < tolerance:
                if verbose:
                    print(f"  converged at iter {i}")
                break
        return self.hypothesis, self.history


# ──────────────────────────────────────────────────────────
# DIAGNOSTICS (turn a probe run into a structured report)
# ──────────────────────────────────────────────────────────
@dataclass
class ProbeReport:
    """Structured summary of a probe run. Suitable for serialization to JSON
    so an LLM agent can read the result."""
    initial_error: float
    final_error: float
    iterations: int
    accept_rate: float
    error_reduction_pct: float
    final_primitives: List[dict]  # each as a small JSON-able dict


def build_report(probe: Probe) -> ProbeReport:
    if not probe.history:
        return ProbeReport(0, 0, 0, 0, 0, [])
    init = probe.history[0].err_before
    final = probe.history[-1].err_after
    n = len(probe.history)
    accept = sum(1 for h in probe.history if h.accepted) / max(1, n)
    reduction = 100.0 * (init - final) / max(1e-6, init)
    prims = [
        {
            "shape": p.shape,
            "center": [round(float(x), 3) for x in p.center],
            "half_extents": [round(float(x), 3) for x in p.half_extents],
            "piece_id": int(p.piece_id),
        }
        for p in probe.hypothesis.primitives
    ]
    return ProbeReport(
        initial_error=round(init, 3),
        final_error=round(final, 3),
        iterations=n,
        accept_rate=round(accept, 3),
        error_reduction_pct=round(reduction, 1),
        final_primitives=prims,
    )
