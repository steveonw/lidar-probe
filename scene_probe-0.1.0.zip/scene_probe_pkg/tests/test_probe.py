"""Unit tests for scene_probe. Run as PYTHONPATH=. python tests/test_probe.py"""
import sys
import copy
import numpy as np

from scene_lens import Camera, Scene, Primitive
from scene_probe import (
    Probe, observe_from_scene, build_orbit_cameras,
    render_hypothesis, image_error, perturb_scene,
    pick_max_error_view, build_report,
)
from scene_probe.probe import Observation

_passed = 0
_failed = 0


def check(name, cond, detail=""):
    global _passed, _failed
    if cond:
        _passed += 1
        print(f"  PASS  {name}")
    else:
        _failed += 1
        print(f"  FAIL  {name}   {detail}")


# ────────────────────────────────────────────────────────────
print("\nimage_error properties")
# ────────────────────────────────────────────────────────────
a = np.zeros((10, 10, 3), dtype=np.uint8)
b = np.zeros((10, 10, 3), dtype=np.uint8)
check("identical images → 0 error", image_error(a, b) == 0.0)

b2 = np.full_like(a, 255)
check("max-different images → 255 error", image_error(a, b2) == 255.0)

b3 = a.copy(); b3[5, 5] = [255, 255, 255]
err = image_error(a, b3)
check("single pixel diff → small positive error",
      0 < err < 10, f"got {err}")


# ────────────────────────────────────────────────────────────
print("\nperturb_scene properties")
# ────────────────────────────────────────────────────────────
R = np.eye(3)
prim = Primitive(
    shape="sphere", center=np.array([0., 0., 0.]),
    half_extents=np.array([1., 1., 1.]),
    rotation_matrix=R, inv_rotation_matrix=R,
    color=(1., 0., 0.), piece_id=1, piece_type="ball",
)
scene = Scene(primitives=[copy.deepcopy(prim)])
rng = np.random.default_rng(0)
new_scene = perturb_scene(scene, rng, pos_sigma=0.5, size_sigma=0.1)

check("perturb returns a new Scene", new_scene is not scene)
check("perturb preserves primitive count",
      len(new_scene.primitives) == len(scene.primitives))
check("perturb does not mutate input scene",
      np.array_equal(scene.primitives[0].center, [0, 0, 0]))
# At least one of (center, half_extents) should have changed
changed = (not np.array_equal(new_scene.primitives[0].center, [0, 0, 0])
           or not np.array_equal(new_scene.primitives[0].half_extents, [1, 1, 1]))
check("perturb changed something", changed)
check("perturbed half_extents stay positive",
      (new_scene.primitives[0].half_extents > 0).all())

# Empty scene
empty = Scene(primitives=[])
result = perturb_scene(empty, rng)
check("perturb empty scene returns valid Scene",
      isinstance(result, Scene))


# ────────────────────────────────────────────────────────────
print("\npick_max_error_view picks worst observation")
# ────────────────────────────────────────────────────────────
# Truth: a sphere at origin
truth = Scene(primitives=[
    Primitive(shape="sphere", center=np.array([0., 0., 0.]),
              half_extents=np.array([1., 1., 1.]),
              rotation_matrix=R, inv_rotation_matrix=R,
              color=(0.8, 0.2, 0.2), piece_id=1, piece_type="b"),
])
# Hypothesis: sphere at WRONG position
hypothesis = Scene(primitives=[
    Primitive(shape="sphere", center=np.array([3., 0., 0.]),  # 3 units off
              half_extents=np.array([1., 1., 1.]),
              rotation_matrix=R, inv_rotation_matrix=R,
              color=(0.8, 0.2, 0.2), piece_id=1, piece_type="b"),
])

# Two cameras: one sees the displacement, one doesn't
cam_side = Camera(position=np.array([0., 0., 5.]), target=np.array([0., 0., 0.]),
                  fov_deg=45, lens="pinhole", width=80, height=60)
cam_top = Camera(position=np.array([1.5, 5., 0.]), target=np.array([1.5, 0., 0.]),
                 up=np.array([0., 0., -1.]),
                 fov_deg=45, lens="pinhole", width=80, height=60)
obs_side = observe_from_scene(truth, cam_side, n_samples=2000)
obs_top = observe_from_scene(truth, cam_top, n_samples=2000)

picked = pick_max_error_view(hypothesis, [obs_side, obs_top])
check("planner returns one of the observations",
      picked is obs_side or picked is obs_top)
# We don't enforce WHICH one — just that it makes a non-arbitrary choice


# ────────────────────────────────────────────────────────────
print("\nProbe convergence: easy 1-primitive recovery")
# ────────────────────────────────────────────────────────────
# Truth: sphere at (2, 1, 0)
truth_simple = Scene(primitives=[
    Primitive(shape="sphere", center=np.array([2., 1., 0.]),
              half_extents=np.array([0.8, 0.8, 0.8]),
              rotation_matrix=R, inv_rotation_matrix=R,
              color=(0.8, 0.3, 0.3), piece_id=1, piece_type="b"),
])
# Hypothesis: sphere at (1, 1, 0) — just 1 unit off
hyp_simple = Scene(primitives=[
    Primitive(shape="sphere", center=np.array([1., 1., 0.]),
              half_extents=np.array([0.8, 0.8, 0.8]),
              rotation_matrix=R, inv_rotation_matrix=R,
              color=(0.8, 0.3, 0.3), piece_id=1, piece_type="b"),
])
cams = build_orbit_cameras(n=6, radius=6, height=2, target=(2, 1, 0),
                           width=120, height_px=90)
observations = [observe_from_scene(truth_simple, c, n_samples=2000, seed=i)
                for i, c in enumerate(cams)]

probe = Probe(hypothesis=hyp_simple, observations=observations,
              perturb_pos_sigma=0.3, perturb_size_sigma=0.05,
              replan_every=4, seed=1)
fitted, history = probe.run(max_iters=60, tolerance=0.1)

check("probe produced history", len(history) > 0)
err_initial = history[0].err_before
err_final = history[-1].err_after
check(f"error decreased (init {err_initial:.1f} → final {err_final:.1f})",
      err_final < err_initial)

# The fitted sphere center should be closer to truth than the initial guess
fitted_center = fitted.primitives[0].center
truth_center = truth_simple.primitives[0].center
initial_dist = float(np.linalg.norm(np.array([1., 1., 0.]) - truth_center))
final_dist = float(np.linalg.norm(fitted_center - truth_center))
check(f"fitted center closer to truth (init dist {initial_dist:.2f} → final {final_dist:.2f})",
      final_dist < initial_dist,
      f"fitted at {fitted_center}, truth at {truth_center}")


# ────────────────────────────────────────────────────────────
print("\nbuild_report serializes the result")
# ────────────────────────────────────────────────────────────
report = build_report(probe)
check("report has initial_error",  report.initial_error > 0)
check("report has final_error",    report.final_error >= 0)
check("report has iterations",     report.iterations == len(history))
check("report has accept_rate",    0.0 <= report.accept_rate <= 1.0)
check("report final_primitives is JSON-friendly",
      isinstance(report.final_primitives, list)
      and all(isinstance(d, dict) for d in report.final_primitives))


# ────────────────────────────────────────────────────────────
print(f"\n{'='*48}\n  {_passed} passed, {_failed} failed\n{'='*48}")
sys.exit(0 if _failed == 0 else 1)
